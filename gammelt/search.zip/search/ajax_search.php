<?

include('Db.php');

class AtlasSearch extends Db {
	private $baseSQL; 
	private $result;

	public function __construct() {
		parent::__construct();

		$this->baseSQL='select distinct spec.genSpec, spec.DKName, atlas.localityBasicString, '.
			'atlas.date_day, atlas.date_month, atlas.date_year, person.AtlaslegInit '.
			'from atlas atlas, atlasSpec spec, atlasPerson person, atlasUTM utm '.
			'where '.
			'atlas._DKIndex=spec.DKIndex '.
			'and atlas._AtlaslegInit=person.AtlaslegInit ';

		header('Content-Type: text/html; charset=ISO-8859-1');

		$this->drawScript();
		$this->evaluateParams();
		$this->performSearch();
		$this->drawTable();
		$this->drawResult();
	}

	private function drawScript() {
?>
<style type="text/css">
.DataTables_sort_wrapper {
	cursor: pointer;
	font-weight: bold;
}
#atlas-result-table td {
	padding-right: 15px;
}
</style>
<script type="text/javascript">
$(document).ready(function() {
	$("#atlas-result-table").dataTable({
		bJQueryUI: true,
	        bPaginate: false,  
	        bInfo: false,  
		bLengthChange: false,
	        bFilter: false,
	        bAutoWidth: false
	});
	$(".dataTables_filter").hide();
	$(".fg-toolbar").hide(); 
});
</script>
<?
	}

	private function drawTable() {
		echo '<table id="atlas-result-table">';
		echo '<thead><tr>';
		echo '<th>Latinsk navn</th>';
		echo '<th>Dansk navn</th>';
		echo '<th>Lokalitet</th>';
		echo '<th>Dato</th>';
		echo '<th>Finder</th>';
		echo '</tr></thead>';
	}

	private function performSearch() {
		//echo $this->baseSQL;
		$this->result=$this->query($this->baseSQL);
	}

	private function drawResult() {		
		echo '<tbody>';
		while ($row=mysql_fetch_array($this->result)) {
			echo '<tr>';
			echo '<td>'.$row['genSpec'].'</td>';
			echo '<td>'.$row['DKName'].'</td>';
			echo '<td>'.$row['localityBasicString'].'</td>';
			echo '<td>'.$row['date_day'].'/'.$row['date_month'].'/'.$row['date_year'].'</td>';
			echo '<td>'.$row['AtlaslegInit'].'</td>';
			echo '</tr>';
		}
		echo '</tbody>';
		echo '</table>';
	}

	private function testParam($param) {
		return ((isset($_GET[$param])) && ($_GET[$param]!=''));
	}

	/* "Manuel" validering af søgekriterierne. Inputparametre har alternative navne ift
	   felterne i FMP og mysql, så der testes individuelt på hver parameter og kreeres et 
	   søgekriterie hvis de er sat
	**/
	private function evaluateParams() {
		if ($this->testParam('finder')) {
			$this->baseSQL.=' and person.AtlaslegInit="'.utf8_decode($_GET['finder']).'"';
		}
		if ($this->testParam('latinnavn')) {
			$this->baseSQL.=' and spec.GenSpec like "%'.$_GET['latinnavn'].'%"';
		}
		if ($this->testParam('dknavn')) {
			$this->baseSQL.=' and spec.DKName like "%'.utf8_decode($_GET['dknavn']).'%"';
		}
		//osv osv
	}

}

$search = new AtlasSearch();

?>
