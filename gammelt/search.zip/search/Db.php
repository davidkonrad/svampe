<?php

class Db {
	private $database;
	private $hostname;
	private $username;
	private $password;
	private $link;
  
	public static function getInstance(){
		static $db = null;
		if ( $db == null ) $db = new Db();
		return $db;
	}

	public function __construct() { 
		$host = $_SERVER["SERVER_ADDR"]; 
		if ($host=='127.0.0.1') {
			$this->database = 'zoo';
			$this->hostname = 'localhost';
			$this->username = 'root';
			$this->password = 'dadk';
		} else {
			$this->database = 'egowheel_com';
			$this->hostname = 'egowheel.com.mysql';
			$this->username = 'egowheel_com';
			$this->password = 'H7vjK6FX';
		}

		try {
			$this->link=mysql_connect($this->hostname,
						  $this->username,
						  $this->password);
			if (!$this->link) {
				die('Could not connect: ' . mysql_error());
			} else {
				mysql_select_db ($this->database);
			}

		} catch (Exception $e){
			throw new Exception('Could not connect to database.');
			exit;
 		}
	}

	public function exec($SQL) {
		mysql_query($SQL);
	}

	public function query($SQL) {
		$result=mysql_query($SQL);
		return $result;
	}

	public function getRow($SQL) {
		$result=mysql_query($SQL);
		$result=mysql_fetch_array($result);
		return $result;
	}

}

?>
