
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta charset="UTF-8" />
<title>Danmarks svampeatlas - mysql test</title> 
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="search.js"></script>
<script type="text/javascript" language="javascript" src="../DataTables-1.7.6/media/js/jquery.dataTables.js"></script> 
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.11/jquery-ui.min.js"></script>
<link rel="stylesheet" href="../DataTables-1.7.6/media/css/demo_table.css" type="text/css" media="screen" />
<link rel="stylesheet" href="../DataTables-1.7.6/media/css/demo_page.css" type="text/css" media="screen" />
</head> 
<body> 
  
     <table border="0" align="left" cellpadding="3" cellspacing="2"> 
        <form action="" method="POST" name="test" id="test"> 
	<tr><td width="29%" align="right" valign="middle" class="mainTextDarkGrey">Søg i UTM-felt:</td>
	<td width="71%" valign="middle" class="mainTextDarkGrey">
	<input name="utm"  type="text" id="utm" size="5" maxlength="4"/></td>
	</tr>
        <tr> 
          <td width="29%" align="right" valign="middle" class="mainTextDarkGrey">Finder:</td> 
		
	      
	          <input type="hidden" name="action" value="soegrec"/> 
			  <input name="latsoeg"  type="hidden" size="15" id="latsoeg" /> 
	          <input name="longsoeg"  type="hidden" size="15" id="longsoeg" /> 
          <td width="71%" valign="middle" class="mainTextDarkGrey"><input name="finder"  type="text" size="45" id="finder"/></td> 
		    <tr> 
		      <td align="right" valign="middle" class="mainTextDarkGrey"> Initialer:</td> 
		      <td valign="middle" class="mainTextDarkGrey"><input name="initialer"  type="text" size="10" id="initialer"/> 
	            | med åben kommentar: 
		         <input name="Spm" id="Spm" type="checkbox" value="Spm" /> 
	          </td> 
	        <tr> 
	          <td align="right" valign="middle" class="mainTextDarkGrey">Databasenummer:</td> 
	          <td valign="middle" class="mainTextDarkGrey"><input name="DBnummer"  type="text" size="15" id="DBnummer"/> 
	          Status:
	            <select name="valistatus" id="valistatus"> 
                  <option value="" selected="selected">V&aelig;lg kategori</option> 
  <option value=">Godkendt">Godkendte</option> 
  <option value="Valideres">Valideres</option> 
  <option value="Afventer">Afventer</option> 
  <option value="Afvist">Afviste</option> 
  <option value="Gammelvali">Ældre fund afventer</option> 
                </select> 
              </td> 
            <tr> 
		        <td align="right" valign="middle" class="mainTextDarkGrey">(Dato) År:</td> 
		        <td valign="middle" class="mainTextDarkGrey"><input name="year"  type="number" size="6" id="year"/> 
Måned:
  <input name="month"  type="number" size="6" id="month"/> 
Dag:
<input name="day"  type="number" size="6" id="day"/></td> 
	        <tr> 
		          <td align="right" valign="middle" class="mainTextDarkGrey">Latinsk
		            navn:</td> 
		          <td valign="middle" class="mainTextDarkGrey"><input name="latinnavn"  type="text" size="45" id="latinnavn"/></td> 
<tr> 
	            <td align="right" valign="middle" class="mainTextDarkGrey">Dansk
	              navn:</td> 
	            <td valign="middle" class="mainTextDarkGrey"> 
	            <input name="dknavn"  type="text" size="45" id="dknavn"/>	            </td> 
            </tr> 
             
		 		 
        <tr> 
          <td align="right" valign="middle" class="mainTextDarkGrey style2">Lokalitet - Kommune:</td> 
          <td valign="middle" class="mainTextDarkGrey"><input name="lokalitet"  type="text" size="22" id="lokalitet"/> 
          -
            <!--<input name="kommune"  type="text" size="20" id="kommune"/> aktiveres når kommune er klar--></td> 
        </tr> 
        <tr> 
          <td align="right" valign="middle" class="mainTextDarkGrey">Rødlistestatus:</td> 
          <td valign="baseline" class="mainTextDarkGrey"><select name="redlist" id="redlist"> 
  <option value="" selected="selected">V&aelig;lg kategori</option> 
  <option value=">10">Alle r&oslash;dlistede</option> 
  <option value="20">RE - Forsvundet</option> 
  <option value="18">CR - Kritisk truet</option> 
  <option value="16">EN - Moderat truet</option> 
  <option value="14">VU - S&aring;rbar</option> 
  <option value="12">NT - N&aelig;sten truet</option> 
  <option value="9">LC - Ikke truet</option> 
  <option value="7">DD - Utilstr&aelig;kkelige data</option> 
  <option value="5">NA - Ikke mulig</option> 
  <option value="0">NE - Ikke bedømt</option> 
          </select>          <br /></td> 
        </tr> 
        <tr> 
        </tr> 
        </form> 
	<tr>
 	<td>&nbsp;</td>
  	<td><input type="button" onclick="atlasSearch.submit();" value="  Søg  " style="width:200px;font-size:1.2em;padding:5px;" /></td>
	</tr>
      </table> 
<div style="width:100%;clear:both;">

<hr> 
<div id="atlasresult"></div>
 
</body> 
</html> 
