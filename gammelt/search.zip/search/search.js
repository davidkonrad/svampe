/* zoo svampe atlas mysql søgning mockup test */

var atlasSearch = {
	init : function() {
	},
	submit : function() {
		var params = $('#test').serialize();
		$("#atlasresult").load('ajax_search.php?'+params);
	}
};
		
	
